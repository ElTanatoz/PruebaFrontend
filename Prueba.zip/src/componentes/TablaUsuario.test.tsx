// src/componentes/TablaUsuario.test.tsx

import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { BrowserRouter } from 'react-router-dom';
import { describe, it, expect } from 'vitest';
import TablaUsuarios from './TablaUsuarios';
import type { User } from '../types/user';

// Datos de prueba con la estructura completa del tipo User
const mockUsers: User[] = [
  { id: 1, name: 'Leanne Graham', username: 'Bret', email: 'Sincere@april.biz', address: { city: 'Gwenborough', street: 'Kulas Light', suite: 'Apt. 556', zipcode: '92998-3874', geo: { lat: '-37.3159', lng: '81.1496' } }, phone: '1-770-736-8031', website: 'hildegard.org', company: { name: 'Romaguera-Crona', catchPhrase: 'Multi-layered client-server neural-net', bs: 'harness real-time e-markets' } },
  { id: 2, name: 'Ervin Howell', username: 'Antonette', email: 'Shanna@melissa.tv', address: { city: 'Wisokyburgh', street: 'Victor Plains', suite: 'Suite 879', zipcode: '90566-7771', geo: { lat: '-43.9509', lng: '-34.4618' } }, phone: '010-692-7768', website: 'anastasia.net', company: { name: 'Deckow-Crist', catchPhrase: 'Proactive didactic contingency', bs: 'synergize scalable supply-chains' } },
  { id: 3, name: 'Clementine Bauch', username: 'Samantha', email: 'Nathan@yesenia.net', address: { city: 'McKenziehaven', street: 'Douglas Extension', suite: 'Suite 847', zipcode: '59590-4157', geo: { lat: '-68.6102', lng: '-47.0653' } }, phone: '1-463-123-4447', website: 'ramiro.info', company: { name: 'Romaguera-Crona', catchPhrase: 'Face to face contingency', bs: 'e-enable strategic applications' } },
];
// ... el resto del código del test

describe('UserTable', () => {
  it('should render the table with correct headers', () => {
    // Renderizamos el componente dentro de BrowserRouter para evitar errores de Link
    render(<BrowserRouter><TablaUsuarios users={mockUsers} /></BrowserRouter>);
    expect(screen.getByText('Nombre')).toBeInTheDocument();
    expect(screen.getByText('Usuario')).toBeInTheDocument();
    expect(screen.getByText('Email')).toBeInTheDocument();
    expect(screen.getByText('Ciudad')).toBeInTheDocument();
  });

  it('should filter users by name', async () => {
    render(<BrowserRouter><TablaUsuarios users={mockUsers} /></BrowserRouter>);
    const input = screen.getByPlaceholderText('Buscar por nombre...');
    await userEvent.type(input, 'Leanne');

    // Solo 'Leanne Graham' debe estar en el documento
    expect(screen.getByText('Leanne Graham')).toBeInTheDocument();
    expect(screen.queryByText('Ervin Howell')).not.toBeInTheDocument();
  });
});