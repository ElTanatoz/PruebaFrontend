
import React, { useState } from 'react';
import type { User } from '../types/user';
import { Link } from 'react-router-dom';

// 1. Definimos la interfaz para las props que el componente espera recibir.
// Esto asegura que el componente siempre reciba un arreglo de 'User'.
interface TablaUsuariosProps {
  users: User[];
}

// 2. Definimos el componente funcional.
const TablaUsuarios: React.FC<TablaUsuariosProps> = ({ users }) => {
  // 3. Usamos 'useState' para gestionar el estado de la búsqueda y el filtro.
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCity, setFilterCity] = useState('');

  // 4. Lógica de filtrado y búsqueda.
  // Filtramos la lista de usuarios en base a los estados 'searchTerm' y 'filterCity'.
  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
    user.address.city.toLowerCase().includes(filterCity.toLowerCase())
  );
  
  // 5. Obtenemos una lista de ciudades únicas para el filtro dropdown.
  const uniqueCities = Array.from(new Set(users.map(user => user.address.city)));

  return (
    <div className="container mx-auto p-4">
      {/* 6. Controles de búsqueda y filtro. */}
      <div className="flex flex-col md:flex-row gap-4 mb-4">
        {/* Input para la búsqueda por nombre */}
        <input
          type="text"
          placeholder="Buscar por nombre..."
          className="border p-2 rounded w-full md:w-1/2"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        {/* Select para el filtro por ciudad */}
        <select
          className="border p-2 rounded w-full md:w-1/2"
          value={filterCity}
          onChange={(e) => setFilterCity(e.target.value)}
        >
          <option value="">Filtrar por ciudad...</option>
          {uniqueCities.map(city => (
            <option key={city} value={city}>{city}</option>
          ))}
        </select>
      </div>

      {/* 7. Mostramos un mensaje si no hay resultados. */}
      {filteredUsers.length === 0 ? (
        <div className="text-center p-8 text-gray-500">
          No se encontraron usuarios que coincidan con la búsqueda.
        </div>
      ) : (
        // 8. Renderizamos la tabla con los usuarios filtrados.
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200">
            <thead className="bg-gray-100">
              <tr>
                <th className="py-2 px-4 border-b text-left">Nombre</th>
                <th className="py-2 px-4 border-b text-left">Usuario</th>
                <th className="py-2 px-4 border-b text-left">Email</th>
                <th className="py-2 px-4 border-b text-left">Ciudad</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map(user => (
                <tr
                  key={user.id}
                  className="hover:bg-gray-50 transition-colors cursor-pointer"
                  tabIndex={0} // Para accesibilidad con teclado
                >
                  {/* 9. Envolvemos la fila en un <Link> para la navegación. */}
                  <Link to={`/users/${user.id}`} className="contents">
                    <td className="py-2 px-4 border-b">{user.name}</td>
                    <td className="py-2 px-4 border-b">{user.username}</td>
                    <td className="py-2 px-4 border-b">{user.email}</td>
                    <td className="py-2 px-4 border-b">{user.address.city}</td>
                  </Link>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default TablaUsuarios;