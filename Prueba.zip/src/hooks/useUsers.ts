
import { useQuery } from '@tanstack/react-query';
import { getUsers, getUserById } from '../servicios/api';

export const useUsers = () => {
  return useQuery({
    queryKey: ['users'],
    queryFn: getUsers,
  });
};

export const useUserById = (userId: string | undefined) => {
  return useQuery({
    queryKey: ['user', userId],
    queryFn: () => getUserById(userId!),
    enabled: !!userId, // Solo ejecuta la query si hay un userId
  });
};