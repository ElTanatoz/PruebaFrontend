
import type { User } from '../types/user';

const API_URL = 'https://jsonplaceholder.typicode.com';

export const getUsers = async (): Promise<User[]> => {
  const response = await fetch(`${API_URL}/users`);
  if (!response.ok) {
    throw new Error('Error al obtener los usuarios.');
  }
  return response.json();
};

export const getUserById = async (id: string): Promise<User> => {
  const response = await fetch(`${API_URL}/users/${id}`);
  if (!response.ok) {
    throw new Error(`Error al obtener el usuario con ID: ${id}`);
  }
  return response.json();
};