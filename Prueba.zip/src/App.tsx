
import { Routes, Route } from 'react-router-dom';
import HomePage from './paginas/Principal';
import DetallesPagina from './paginas/DetallesPagina';

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/users/:id" element={<DetallesPagina />} />
      <Route path="*" element={<div>Página no encontrada</div>} />
    </Routes>
  );
};

export default App;