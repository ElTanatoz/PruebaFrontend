import React from 'react';
import { useUsers } from '../hooks/useUsers';
import TablaUsuarios from '../componentes/TablaUsuarios';

const Principal: React.FC = () => {
  const { data: users, isLoading, isError } = useUsers();

  if (isLoading) return <div>Cargando usuarios...</div>;
  if (isError) return <div>Error al cargar los datos.</div>;

  return (
    <main className="p-4">
      <h1 className="text-2xl font-bold mb-4">Listado de Usuarios</h1>
      {users && <TablaUsuarios users={users} />}
    </main>
  );
};

export default Principal;