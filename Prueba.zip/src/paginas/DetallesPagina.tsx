
import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useUserById } from '../hooks/useUsers';

const DetallesPagina: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { data: user, isLoading, isError } = useUserById(id);
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <p>Cargando detalles del usuario...</p>
      </div>
    );
  }

  if (isError || !user) {
    return (
      <div className="flex flex-col justify-center items-center h-screen text-red-600">
        <p>Error: Usuario no encontrado o no se pudieron cargar los datos.</p>
        <button
          onClick={() => navigate(-1)}
          className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          Volver
        </button>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 md:p-8">
      <button
        onClick={() => navigate(-1)}
        className="mb-4 px-4 py-2 bg-gray-200 rounded hover:bg-gray-300"
      >
        &larr; Volver al listado
      </button>

      {/* Tarjeta con los detalles del usuario */}
      <div className="bg-white shadow-lg rounded-lg p-6">
        <h1 className="text-3xl font-bold mb-4">{user.name}</h1>
        <h2 className="text-xl text-gray-600 mb-6">@{user.username}</h2>
        
        {/* Información personal */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-semibold mb-2">Información de Contacto</h3>
            <p className="text-gray-700"><strong>Email:</strong> {user.email}</p>
            <p className="text-gray-700"><strong>Teléfono:</strong> {user.phone}</p>
            <p className="text-gray-700"><strong>Sitio Web:</strong> {user.website}</p>
          </div>
          
          {/* Dirección */}
          <div>
            <h3 className="text-lg font-semibold mb-2">Dirección</h3>
            <p className="text-gray-700"><strong>Calle:</strong> {user.address.street}</p>
            <p className="text-gray-700"><strong>Ciudad:</strong> {user.address.city}</p>
            <p className="text-gray-700"><strong>Código Postal:</strong> {user.address.zipcode}</p>
          </div>
          
          {/* Compañía */}
          <div>
            <h3 className="text-lg font-semibold mb-2">Compañía</h3>
            <p className="text-gray-700"><strong>Nombre:</strong> {user.company.name}</p>
            <p className="text-gray-700"><strong>Lema:</strong> {user.company.catchPhrase}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DetallesPagina;