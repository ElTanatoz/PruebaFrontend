
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { describe, it, expect, vi } from 'vitest';
import App from './App';


// Mock de las funciones de la API
vi.mock('./servicios/api', () => ({
  getUsers: vi.fn(() =>
    Promise.resolve([
      { id: 1, name: 'Leanne Graham', username: 'Bret', email: 'Sincere@april.biz', address: { city: 'Gwenborough' } },
      { id: 2, name: 'Ervin Howell', username: 'Antonette', email: 'Shanna@melissa.tv', address: { city: 'Wisokyburgh' } },
    ])
  ),
  getUserById: vi.fn(() =>
    Promise.resolve({ id: 1, name: 'Leanne Graham', username: 'Bret', email: 'Sincere@april.biz', address: { street: 'Kulas Light', suite: 'Apt. 556', city: 'Gwenborough', zipcode: '92998-3874', geo: { lat: '-37.3159', lng: '81.1496' } }, phone: '1-770-736-8031', website: 'hildegard.org', company: { name: 'Romaguera-Crona', catchPhrase: 'Multi-layered client-server neural-net', bs: 'harness real-time e-markets' } })
  ),
}));

describe('User Flow Integration Test', () => {
  it('should navigate from the list to user detail and back', async () => {
    const queryClient = new QueryClient();

    render(
      <QueryClientProvider client={queryClient}>
        <MemoryRouter initialEntries={['/']}>
          <App />
        </MemoryRouter>
      </QueryClientProvider>
    );

    // 1. Esperar a que la lista de usuarios se cargue
    await waitFor(() => {
      expect(screen.getByText('Leanne Graham')).toBeInTheDocument();
    });

    // 2. Hacer clic en el usuario 'Leanne Graham'
    await userEvent.click(screen.getByText('Leanne Graham'));

    // 3. Verificar que la vista de detalle se muestre
    await waitFor(() => {
      expect(screen.getByText(/Información de Contacto/i)).toBeInTheDocument();
      expect(screen.getByText('Sincere@april.biz')).toBeInTheDocument();
    });

    // 4. Volver al listado
    await userEvent.click(screen.getByText('← Volver al listado'));

    // 5. Verificar que la lista se muestre de nuevo
    await waitFor(() => {
      expect(screen.getByText('Listado de Usuarios')).toBeInTheDocument();
    });
  });
});